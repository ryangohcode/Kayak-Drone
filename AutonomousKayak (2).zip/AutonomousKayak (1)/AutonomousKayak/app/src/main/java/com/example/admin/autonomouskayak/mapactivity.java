package com.example.admin.autonomouskayak;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.View;
import android.widget.Toast;


import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;



public class mapactivity extends FragmentActivity implements OnMapClickListener,OnMapLongClickListener, OnMapReadyCallback {
    private ArrayList<LatLng> arrayPoints;
    GoogleMap mGoogleMap;


    @Override
    public void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.map_activity);

        MapsInitializer.initialize(getApplicationContext());


        this.init();
    }

    private void init() {

        SupportMapFragment mapFragment = (SupportMapFragment)
                this.getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        GooglePlayServicesUtil.isGooglePlayServicesAvailable(
                mapactivity.this);


        arrayPoints = new ArrayList<LatLng>();
    }

    @Override
    public void onMapClick(LatLng latLng) {

        //add marker
        MarkerOptions marker=new MarkerOptions();
        marker.position(latLng);
        mGoogleMap.addMarker(marker);

        PolylineOptions polylineOptions = new PolylineOptions();
        polylineOptions.color(Color.RED);
        polylineOptions.width(5);
        arrayPoints.add(latLng);
        polylineOptions.addAll(arrayPoints);
        mGoogleMap.addPolyline(polylineOptions);
    }

    @Override
    public void onMapLongClick(LatLng arg0) {
        mGoogleMap.clear();
        arrayPoints.clear();
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        try {
            googleMap.setMyLocationEnabled(true);
        } catch (SecurityException e) {
        }
        googleMap.setOnMapClickListener(this);
        googleMap.setOnMapLongClickListener(this);

        String coordinates[] = { "1.301183", "103.870030"};
        double lat = Double.parseDouble(coordinates[0]);
        double lng = Double.parseDouble(coordinates[1]);
        LatLng position = new LatLng(lat, lng);
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(position, 15));
        mGoogleMap = googleMap;
    }

    public void launch(View view) {
        Toast.makeText(getApplicationContext(),"Launching mission", Toast.LENGTH_SHORT).show();
        finish();
    }
}
